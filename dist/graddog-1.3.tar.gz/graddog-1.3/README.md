# cs107-FinalProject
## Group 22
Group Members:  
* Guanhua Shu
* Max Cembalest
* Seeam Noor
* Peyton Benac

[![codecov](https://codecov.io/gh/git-fetch-git-roll-over/AutoDiff/branch/master/graph/badge.svg)](https://codecov.io/gh/git-fetch-git-roll-over/AutoDiff)
[![Build Status](https://travis-ci.com/git-fetch-git-roll-over/AutoDiff.svg?branch=master)](https://travis-ci.com/git-fetch-git-roll-over/AutoDiff)
